import Vue from "vue";
import Vuex from "vuex";
import Axios from "axios";

import CartModule from "./cart";
import OrdersModule from "./orders";
import AuthModule from "./auth";

//Vuex is distributed as a Vue.js plugin. Plugins must be enabled using the Vue.use method
Vue.use(Vuex);

/*
接下来要通过REST API来获取数据
const testData = [];
for (let i = 1; i <= 10; i++) {
	testData.push({
		id: i, name: `Product #${i}`, category: `Category ${i % 3}`,
		description: `This is Product #${i}`, price: i * 50
	})
}*/
const baseUrl = "http://localhost:3500";
const productsUrl = `${baseUrl}/products`;
const categoriesUrl = `${baseUrl}/categories`;

//create a Vuex.Store object, passing a configuration object
/*
vuex的state和vue的data有很多相似之处,都是用于存储一些数据,或者说状态值.这些值都将被挂载.
state在使用的时候一般被挂载到子组件的computed计算属性上,这样有利于state的值发生改变的时候及时响应给子组件

*/
export default new Vuex.Store({
	//strict mode is a useful feature that generates a warning if you forget to use 
	//a mutation and modify data values directly
	strict: true,
	//I added the modules property, which is assigned an object whose property name specifies the prefix 
	//that will be used to access the features in the module and whose value is the module object.
	//这里，the features in the new data store module will be accessed using the prefix cart.
	modules: { cart: CartModule, orders: OrdersModule, auth: AuthModule },
	state: {
		//products: [],//testData,
		//用于分页
		//productsTotal: 0,//testData.length,		
		currentPage: 1,
		pageSize: 4,
		currentCategory: "All",
		categoriesData: [],

		pages: [],
		serverPageCount: 0,
		searchTerm: "",
		showSearch: false
	},
	getters: {
		processedProducts: (state) => {return state.pages[state.currentPage];},
		pageCount: (state) => state.serverPageCount,
		categories: state => ["All", ...state.categoriesData],
		productById:(state) => (id) => {
			return state.pages[state.currentPage].find(p => p.id == id);
		}
	},
	/*
	The separation between standard data properties and computed properties is a theme that runs
through Vue.js development because it allows for efficient change-detection. When a data property changes,
Vue.js is able to determine the effect on the computed property and doesn’t have to recalculate values
when the underlying data has not changed

	*/
	mutations: {
/* both the getters and the mutations are defined as functions that receive a state object as their first parameter.  */
		_setCurrentPage(state, page) {
			state.currentPage = page;
		},
		_setPageSize(state, size) {
			state.pageSize = size;
			state.currentPage = 1;
		},
		_setCurrentCategory(state, category) {
			state.currentCategory = category;
			state.currentPage = 1;
		},
		addPage(state, page) {
			for (let i = 0; i < page.pageCount; i++) {
				/*replace items in an array using Vue.set。The Vue.set method accepts three arguments: the object or array to modify, the property or index to
assign to, and the value to assign*/
				/*
Vue.js and Vuex both do a good job of tracking changes and ensuring that the data in the application is live.
For the most part, this tracking is automatic, and no special actions are required. But this isn’t universally
true, and there are some limitations in the way that JavaScript works that mean Vue.js requires some
assistance for certain operations, one of which is assigning an item to an array index, which won’t trigger
the change detection process. 使用Vue.set方法则可以做到:
				*/
				Vue.set(state.pages, page.number + i,
				page.data.slice(i * state.pageSize,(i * state.pageSize) + state.pageSize));
			}
		},
		clearPages(state) {
			//Removes the amount of elements denoted by length starting at startIndex
			state.pages.splice(0, state.pages.length);
		},
		setCategories(state, categories) {
			state.categoriesData = categories;
		},
		//背后变动的是需要展示多少页
		setPageCount(state, count) {
			state.serverPageCount = Math.ceil(Number(count) / state.pageSize);
		},
		setShowSearch(state, show) {
			state.showSearch = show;
		},
		setSearchTerm(state, term) {
			state.searchTerm = term;
			state.currentPage = 1;
		},
		_addProduct(state, product) {
			//Adds elements to the beginning of the array and returns the new length.
			/*
这个实现有个折中：When a product is added, I insert it at the start of the current page of products, 
even though this means the page size is incorrect, so that I don’t have to figure out which page 
the new object should be displayed on and get that data from the server.
			*/
			state.pages[state.currentPage].unshift(product);
		},
		_updateProduct(state, product) {
			let page = state.pages[state.currentPage];
			let index = page.findIndex(p => p.id == product.id);
			Vue.set(page, index, product);
		}
	},
	/*
	Vuex supports asynchronous tasks using a feature called actions.
	In Vuex，only actions can perform asynchronous tasks. 这也意味着 that any activity that leads to an
HTTP request for data has to be performed using an action, and actions change state using mutations
	*/
	actions: {
		async getData(context) {
			//获取两页数据
			await context.dispatch("getPage", 2);
			context.commit("setCategories", (await Axios.get(categoriesUrl)).data);
		},
		async getPage(context, getPageCount = 1) {
			let url = `${productsUrl}?_page=${context.state.currentPage}`
			+ `&_limit=${context.state.pageSize * getPageCount}`;
			if (context.state.currentCategory != "All") {
				url += `&category=${context.state.currentCategory}`;}
			if (context.state.searchTerm != "") {
				url += `&q=${context.state.searchTerm}`;}
			/*这个url值得关注
The json-server package that is providing the web service includes support for requested pages of data
and for filtering data, using URLs like this one:    
http://localhost:3500/products?_page=3&_limit=4&category=Watersports

再比如 A URL requests the third page of four items whose category property is Soccer and have any field
that contains the term car就可以使用下面这个URL
http://localhost:3500/products?_page=3&_limit=4&category=Soccer&q=qui
			*/
			let response = await Axios.get(url);
/*the json-server package includes an X-Total-Count header in its responses, which indicates how many 
objects are in the collection. Each time that an HTTP request is made for a page of data, I get the 
value of the header from the response and use it to update
the page count*/
			context.commit("setPageCount", response.headers["x-total-count"]);
			context.commit("addPage", { number: context.state.currentPage,
			data: response.data, pageCount: getPageCount});
			//page.number, page.data,page.pageCount
		},
		setCurrentPage(context, page) {
			context.commit("_setCurrentPage", page);
			/*
The application keeps track of the data it has received from the web service and sends an HTTP request
when the user navigates to a page for which no data has been requested
			*/
			if (!context.state.pages[page]) {//如果没有缓存这一页数据，则去取一页数据
				context.dispatch("getPage");
			}
		},
		setPageSize(context, size) {
			context.commit("clearPages");
			context.commit("_setPageSize", size);
			context.dispatch("getPage", 2);//重新进行第一次取2页数据的操作
		},
		setCurrentCategory(context, category) {
			context.commit("clearPages");
			context.commit("_setCurrentCategory", category);
			context.dispatch("getPage", 2);//重新进行第一次取2页数据的操作
		},
		search(context, term) {
			context.commit("setSearchTerm", term);
			context.commit("clearPages");
			context.dispatch("getPage", 2);
		},
		clearSearchTerm(context) {
			context.commit("setSearchTerm", "");
			context.commit("clearPages");
			context.dispatch("getPage", 2);
		},
		async addProduct(context, product) {
			let data = (await context.getters.authenticatedAxios.post(productsUrl,product)).data;
			product.id = data.id;
			/*
The actions will be invoked by components to store, remove, or change a product, which requires an
HTTP request to the web service and a corresponding change to the local data。请关注内存中的数据是如何更新的
			*/			
			this.commit("_addProduct", product);
		},
		async removeProduct(context, product) {
			await context.getters.authenticatedAxios.delete(`${productsUrl}/${product.id}`);
			context.commit("clearPages");
			context.dispatch("getPage", 2);
		},
		async updateProduct(context, product) {
			await context.getters.authenticatedAxios.put(`${productsUrl}/${product.id}`, product);
			this.commit("_updateProduct", product);
		}
	}
})