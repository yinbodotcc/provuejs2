import Vue from "vue";
import VueRouter from "vue-router";

import Store from "../components/Store";
import ShoppingCart from "../components/ShoppingCart";
import Checkout from "../components/Checkout";
import OrderThanks from "../components/OrderThanks";

import Authentication from "../components/admin/Authentication";
import Admin from "../components/admin/Admin";

import dataStore from "../store";
import ProductAdmin from "../components/admin/ProductAdmin";
import OrderAdmin from "../components/admin/OrderAdmin";

import ProductEditor from "../components/admin/ProductEditor";

Vue.use(VueRouter);

export default new VueRouter({
	mode: "history",
	routes: [
		{ path: "/", component: Store },
		{ path: "/cart", component: ShoppingCart },
		{ path: "/checkout", component: Checkout},
		/*The colon in the second segment of the URL tells the routing system that this route should
match any two segment URL where the first segment is thanks. The content of the second URL segment will
be assigned to a variable named id, which is then displayed to the user by the OrderThanks component */
		{ path: "/thanks/:id", component: OrderThanks},		
		{ path: "/login", component: Authentication },
		{ path: "/admin", component: Admin,
		//The beforeEnter function is invoked when the user navigates to the /admin URL
			beforeEnter(to, from, next) {
				/*
The mapState helper function that I used in earlier examples and the $store property that can be used to access the data store directly
can be used only in components and isn’t available elsewhere in the application, such as in the routing
configuration
				*/
				//router/index.js中有modules: { cart: CartModule, orders: OrdersModule, auth: AuthModule },
				if (dataStore.state.auth.authenticated) {next();} 
				else {next("/login");}
			},
			/*
The new additions use the child route feature, which I describe in Chapter 23 and which allows nested
router-view elements to be used. The result is that navigating to /admin/products will display the Admin
component at the top level and then the ProductAdmin component
通俗一点说，就是ProductAdmin内嵌在整个Admin组件里面
			*/
			children: [
			//the Vue Router package is able to handle complex patterns when it matches URLs and includes support for regular expressions.
				{ path: "products/:op(create|edit)/:id(\\d+)?", component: ProductEditor },
				{ path: "products", component: ProductAdmin },
				{ path: "orders", component: OrderAdmin },
				{ path: "", redirect: "/admin/products"}
			]
		},
		{ path: "*", redirect: "/"}
	]
})