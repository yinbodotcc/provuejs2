<template>
	<tr>
		<td>
			<input type="number" class="form-control-sm"
			style="width:5em"
			v-bind:value="qvalue"
			v-on:input="sendChangeEvent"/>
		</td>
		<td>{{ line.product.name }}</td>
		<td class="text-right">
			{{ line.product.price | currency }}<!--currency定义在main.js中-->
		</td>
		<td class="text-right">
			{{ (line.quantity * line.product.price) | currency }}
		</td>
		<td class="text-center">
			<!--.btn-sm for small buttons-->
			<button class="btn btn-sm btn-danger" v-on:click="sendRemoveEvent">
				Remove
			</button>
		</td>
	</tr>
</template>
<script>
	export default {
		/*
	This component uses the props feature, which allows the parent component to provide data objects to its children.  它的parent会使用这个line去provide the line from the shopping cart that it will display to the user
		*/
		props: ["line"],
		data: function() {
			return {
				qvalue: this.line.quantity
			}
		},
		//This component also sends custom event, which it uses to communicate with its parent.
		methods: {
			sendChangeEvent($event) {
				if ($event.target.value > 0) {
					//send an event to its parent component. These features are a useful way to connect components to create features that are local to one part of the application without using global features like the data store
					this.$emit("quantity", Number($event.target.value));
					this.qvalue = $event.target.value;
				} else {
					this.$emit("quantity", 1);
					this.qvalue = 1;
					$event.target.value = this.qvalue;
				}
			},
			sendRemoveEvent() {
				this.$emit("remove", this.line);
			}
		}
	}
</script>