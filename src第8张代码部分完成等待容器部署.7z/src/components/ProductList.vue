<template>
	<div>
		<div v-for="p in products" v-bind:key="p.id" class="card m-1 p-1 bg-light">
			<h4>
				<!--data binding-->
				{{p.name}}
				<span class="badge badge-pill badge-primary float-right">
					{{ p.price | currency }}<!--currency是一个自定义的filter，used to format data values-->
				</span>
			</h4>
			<div class="card-text bg-white p-1">{{ p.description }}
				<button class="btn btn-success btn-sm float-right" v-on:click="handleProductAdd(p)">
						Add To Cart
				</button>
			</div>
		</div>
		<page-controls />
	</div>
</template>

<script>
	import { mapGetters, mapMutations } from "vuex";	
	import PageControls from "./PageControls";

	export default {
		components: { PageControls },
		//the computed property, which is providing access to the data in the data store
		computed: {
			/*
1. mapState function is used with the spread operator because it can map multiple data store properties in a single operation, even though only the products state property is mapped in this example.

2. The result of using the mapState function is that I can use the products property with the v-for directive to access the data in the data store
			*/
			//...mapState(["products"])//Using the Spread Operator
			/*
注意下面这个写法
allows me to specify that the processedProducts getter will be mapped using the name products
			*/
			...mapGetters({ products: "processedProducts" })
		},
		//the filters property, which is used to define filters
		filters: {
			currency(value) {
				/*
new Intl.NumberFormat([locales[, options]])
options 可以包含下面的属性：
	1. style
	    The formatting style to use. Possible values are "decimal" for plain number formatting, "currency" for currency formatting, and "percent" for percent formatting; the default is "decimal".
	2. currency
        The currency to use in currency formatting. Possible values are the ISO 4217 currency codes, such as "USD" for the US dollar, "EUR" for the euro, or "CNY" for the Chinese RMB — see the Current currency & funds code list. There is no default value; if the style is "currency", the currency property must be provided.
				*/

			return new Intl.NumberFormat("zh-CN",{ style: "currency", currency: "CNY" })
				.format(value);
			/*return new Intl.NumberFormat("en-US",{ style: "currency", currency: "USD" })
				.format(value);*/
			}
		},
		methods: {
			//which is the way that the prefix I specified in Listing 6-7 allows me to access the features in the module when the namespaced property is true.
			//The functionality provided by the Vue Router package is provided to components using the $router property (accessing all properties and methods in a component requires using the this keyword). The push method tells the router to change the browser’s URL, which has the effect of displaying a different component.
			...mapMutations({ addProduct: "cart/addProduct" }),
			handleProductAdd(product) 
			{
				this.addProduct(product);
				//uses the routing system to navigate to the /cart URL
				this.$router.push("/cart");
			}
		}




	}
</script>