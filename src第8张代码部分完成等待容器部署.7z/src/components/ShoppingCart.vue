<template>
	<div class="container-fluid">
		<div class="row">
			<div class="col bg-dark text-white">
				<a class="navbar-brand">SPORTS STORE</a>
			</div>
		</div>
		<div class="row">
			<div class="col mt-2">
				<h2 class="text-center">Your Cart</h2>
				<table class="table table-bordered table-striped p-2">
					<!--表头-->
					<thead>
						<tr>
							<th>Quantity</th><th>Product</th>
							<th class="text-right">Price</th>
							<th class="text-right">Subtotal</th>
						</tr>
					</thead>
					<tbody>
						<tr v-if="lines.length == 0">
							<td colspan="4" class="text-center">
							Your cart is empty
							</td>
						</tr>
						<!--整行对应-->
						<!--下面有一行代码： import CartLine from "./ShoppingCartLine";
                            1. v-bind:line="line" 使得ShoppingCartLine.vue中的props: ["line"]里面的line获得了值，从而使得里面的<template>里面的内容得到填充. 
                            2. the v-on directive is used to receive the custom events emitted by the CartLine directive。 子component里面有： this.$emit("quantity", Number($event.target.value));下面的v-on:quantity中的quantity实际是事件名 
                            3. v-on:remove="remove" remove方法的参数应当默认是从this.$emit("remove", this.line);中传递过来的this.line

						-->
						<cart-line v-for="line in lines" v-bind:key="line.product.id"
						v-bind:line="line" 						
						v-on:quantity="handleQuantityChange(line, $event)"
						v-on:remove="remove" />
					</tbody>
					<tfoot v-if="lines.length > 0">
						<tr>
							<td colspan="3" class="text-right">Total:</td>
							<td class="text-right">
							{{ totalPrice | currency }}
							</td>
						</tr>
					</tfoot>
				</table>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<div class="text-center">
					<!-- The router-link element is provided by the Vue Router package, and it is used to generate a navigation element.When the component’s template is processed, the router-link element is replaced with an anchor element (an element whose tag is a) that will navigate to the URL specified by the to attribute.
					-->
					<router-link to="/" class="btn btn-secondary m-1">
					Continue Shopping
					</router-link>
					<!--引向Checkout.vue 组件-->
					<router-link to="/checkout" class="btn btn-primary m-1"
					v-bind:disabled="lines.length == 0">
					Checkout
					</router-link>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import { mapState, mapMutations, mapGetters } from "vuex";
	import CartLine from "./ShoppingCartLine";
	export default {
		components: { CartLine },
		computed: {
			/*
			1. cart.js中定义的state
			2. When mapping getters, mutations, and actions, the prefix is included in the name, but a different approach is required for accessing state properties.State properties are mapped by defining a function that receives the state object and selects the property that is required. In this case, the selected property is lines, which is accessed using the cart prefix.
			*/
			...mapState({ lines: state => state.cart.lines }),//注意这里的cart
			...mapGetters({ totalPrice : "cart/totalPrice" })
		},
		methods: {
			...mapMutations({
				change: "cart/changeQuantity",
				remove: "cart/removeProduct"
			}),
			handleQuantityChange(line, $event) {
				this.change({ line, quantity: $event});
			}
		}
	}
</script>