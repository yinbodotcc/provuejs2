<template>
	<div class="container-fluid">
		<div class="row my-2" v-for="c in categories" v-bind:key="c">
			<button class="btn btn-block"
				v-on:click="setCurrentCategory(c)"
				v-bind:class="c == setCurrentCategory ? 'btn-primary' : 'btn-secondary'">
				{{ c }}
			</button>
		</div>
	</div>
</template>

<script>
	//import { mapState, mapGetters, mapMutations} from "vuex";
	//import { mapGetters, mapMutations} from "vuex";
	import { mapState, mapGetters, mapActions} from "vuex";
	export default {
		computed: {
			...mapState(["currentCategory"]),//这个暂时没有什么用处，是可以屏蔽掉的
			...mapGetters(["categories"])
		},
		methods: {
			//...mapMutations(["setCurrentCategory"])
			...mapActions(["setCurrentCategory"])
		}
	}
</script>