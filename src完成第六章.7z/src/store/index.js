import Vue from "vue";
import Vuex from "vuex";
import Axios from "axios";

import CartModule from "./cart";
import OrdersModule from "./orders";

//Vuex is distributed as a Vue.js plugin. Plugins must be enabled using the Vue.use method
Vue.use(Vuex);

/*
接下来要通过REST API来获取数据
const testData = [];
for (let i = 1; i <= 10; i++) {
	testData.push({
		id: i, name: `Product #${i}`, category: `Category ${i % 3}`,
		description: `This is Product #${i}`, price: i * 50
	})
}*/
const baseUrl = "http://localhost:3500";
const productsUrl = `${baseUrl}/products`;
const categoriesUrl = `${baseUrl}/categories`;

//create a Vuex.Store object, passing a configuration object
/*
vuex的state和vue的data有很多相似之处,都是用于存储一些数据,或者说状态值.这些值都将被挂载.
state在使用的时候一般被挂载到子组件的computed计算属性上,这样有利于state的值发生改变的时候及时响应给子组件

*/
export default new Vuex.Store({
	//strict mode is a useful feature that generates a warning if you forget to use 
	//a mutation and modify data values directly
	strict: true,
	//I added the modules property, which is assigned an object whose property name specifies the prefix 
	//that will be used to access the features in the module and whose value is the module object.
	//这里，the features in the new data store module will be accessed using the prefix cart.
	modules: { cart: CartModule, orders: OrdersModule },
	state: {
		products: [],//testData,
		//用于分页
		productsTotal: 0,//testData.length,
		currentPage: 1,
		pageSize: 4,
		currentCategory: "All",
		categoriesData: [],
	},
	getters: {
		/*processedProducts: state => {
			let index = (state.currentPage -1) * state.pageSize;
			return state.products.slice(index, index + state.pageSize);
		},
		pageCount: state => Math.ceil(state.productsTotal / state.pageSize)*/

		productsFilteredByCategory: state => state.products.filter(p => state.currentCategory == "All"
			|| p.category == state.currentCategory),
		processedProducts: (state, getters) => {
			let currentPageStartIndex = (state.currentPage -1) * state.pageSize;
			return getters.productsFilteredByCategory
			.slice(currentPageStartIndex, currentPageStartIndex + state.pageSize);
			},
		pageCount: (state, getters) =>
			Math.ceil(getters.productsFilteredByCategory.length / state.pageSize),
		categories: state => ["All", ...state.categoriesData]
		/*  上一个迭代的写法是：
			categories: state => ["All", ...new Set(state.products.map(p => p.category).sort())]
		*/
	},
	/*
	The separation between standard data properties and computed properties is a theme that runs
through Vue.js development because it allows for efficient change-detection. When a data property changes,
Vue.js is able to determine the effect on the computed property and doesn’t have to recalculate values
when the underlying data has not changed

	*/
	mutations: {
/* both the getters and the mutations are defined as functions that receive a state object as their first parameter.  */
		setCurrentPage(state, page) {
			state.currentPage = page;
		},
		setPageSize(state, size) {
			state.pageSize = size;
			state.currentPage = 1;
		},
		setCurrentCategory(state, category) {
			state.currentCategory = category;
			state.currentPage = 1;
		},
		setData(state, data) {
			state.products = data.pdata;
			state.productsTotal = data.pdata.length;
			state.categoriesData = data.cdata.sort();
		}
	},
	//Vuex supports asynchronous tasks using a feature called actions
	actions: {
		async getData(context) {
			//get the product and category data from the server
			let pdata = (await Axios.get(productsUrl)).data;
			let cdata = (await Axios.get(categoriesUrl)).data;
			context.commit("setData", { pdata, cdata} );
		}
	}
})