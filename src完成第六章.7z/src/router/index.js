import Vue from "vue";
import VueRouter from "vue-router";

import Store from "../components/Store";
import ShoppingCart from "../components/ShoppingCart";
import Checkout from "../components/Checkout";
import OrderThanks from "../components/OrderThanks";

Vue.use(VueRouter);

export default new VueRouter({
	mode: "history",
	routes: [
		{ path: "/", component: Store },
		{ path: "/cart", component: ShoppingCart },
		{ path: "/checkout", component: Checkout},
		/*The colon in the second segment of the URL tells the routing system that this route should
match any two segment URL where the first segment is thanks. The content of the second URL segment will
be assigned to a variable named id, which is then displayed to the user by the OrderThanks component */
		{ path: "/thanks/:id", component: OrderThanks},
		{ path: "*", redirect: "/"}
	]
})