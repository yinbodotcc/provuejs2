<template>
	<div v-if="show" class="text-danger">
		<div v-for="m in messages" v-bind:key="m">{{ m }}</div>
	</div>
</template>
<script>
	export default {
		/*
The Vuelidate package provides details about data validation through an object that will be received by this component’s validation prop
		*/
		props: ["validation"],
		computed: {
			show() {
				//this.validation.$dirty为true则表示the element has been edited by the user.
				//$invalid : If this property is true, then the element contents have contravened one of the validation rules that has been applied.
				return this.validation.$dirty && this.validation.$invalid
			},
			messages() {
				let messages = [];
				//If this property is true, then the element has been edited by the user.
				if (this.validation.$dirty) {
					/*
					对于这个应用，我使用了2个validators： 
					1. required validator，它 ensures the user has provided a value 
					2. email validator，它 ensures a value is a correctly formatted e-mail address.
					*/
					if (this.hasValidationError("required")) {
						messages.push("Please enter a value")
					} else if (this.hasValidationError("email")) {
						messages.push("Please enter a valid email address");
					}
				}
				return messages;
			}
		},
		methods: {
			hasValidationError(type) {
				//type在这里指一个validator
				return this.validation.$params.hasOwnProperty(type)
				&& !this.validation[type];
			}
		}
	}
</script>