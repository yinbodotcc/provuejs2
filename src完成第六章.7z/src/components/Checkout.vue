<template>
	<div>
		<div class="container-fluid">
			<div class="row">
				<div class="col bg-dark text-white">
					<a class="navbar-brand">SPORTS STORE</a>
				</div>
			</div>
		</div>
		<div class="m-2">
			<div class="form-group m-2">
				<label>Name</label>
				<!--use of the v-model directive to the input element, which creates a two-way binding with the name property, which keeps the value of the name property and the contents of the input element synchronized.
					但是请注意： it cannot be used with values from the data store since Vuex requires changes to be performed using mutations, which the v-model directive doesn’t support-->
				<!--input v-model="name" class="form-control "/-->
				<!--
Validation features are accessed through a property called $v, 后面的order.name属性对应于the name data value, and its value is accessed using the $model property.
				-->
				<input v-model="$v.order.name.$model" class="form-control "/>
				<validation-error v-bind:validation="$v.order.name" />


			</div>
			<div class="m-2">
				<div class="form-group m-2">
					<label>Email</label>
					<input v-model="$v.order.email.$model" class="form-control "/>
					<validation-error v-bind:validation="$v.order.email" />
				</div>
			</div>
			<div class="m-2">
				<div class="form-group m-2">
					<label>Address</label>
					<input v-model="$v.order.address.$model" class="form-control "/>
					<validation-error v-bind:validation="$v.order.address" />
				</div>
			</div>
			<div class="m-2">
				<div class="form-group m-2">
					<label>City</label>
					<input v-model="$v.order.city.$model" class="form-control "/>
					<validation-error v-bind:validation="$v.order.city" />
				</div>
			</div>
			<div class="m-2">
				<div class="form-group m-2">
					<label>Zip</label>
					<input v-model="$v.order.zip.$model" class="form-control "/>
					<validation-error v-bind:validation="$v.order.zip" />
				</div>
			</div>
		</div>
		<div class="text-center">
			<!--回到购物车页面-->
			<router-link to="/cart" class="btn btn-secondary m-1">
				Back
			</router-link>
			<button class="btn btn-primary m-1" v-on:click="submitOrder">
				Place Order
			</button>
		</div>
	</div>
</template>

<script>

import { required, email } from "vuelidate/lib/validators";
import ValidationError from "./ValidationError";
import { mapActions } from "vuex";

/*
我会增加一个新的路由   { path: "/checkout", component: Checkout},
*/
	export default {
		components: { ValidationError },
		/*
This fragment of code defines a single local data property called name, whose initial value is null. You
will become used to this expression as you become experienced in Vue.js development and it soon becomes
second nature.
		*/
		data: function() {
			return {
				/*
I have grouped the data properties together so they are nested under an order object
				*/
				order: {
					name: null,
					email: null,
					address: null,
					city: null,
					zip: null
				}
			}
		},
/*
Vuelidate data validation is applied using a validations property in the script elements , which has properties that correspond to the name of the data value that will be validated

*/
		validations: {
			//和上面data里面的order里面的内容是一致的			
			order: {
				//applied the "required" validator, which must be imported from the veulidate/lib/validators
				name: { required },
				email: { required, email },
				address: { required },
				city: { required },
				zip: { required }
			}
		},
		methods: {
			...mapActions({
				"storeOrder": "storeOrder",
				"clearCart": "cart/clearCartData"
			}),
			async submitOrder() {
			//The $v object defines a $touch method, which marks all of the elements as dirty, as though the user had edited them
				this.$v.$touch();
				//I check the $v.$isvalid property, which reports on the validity of all of the validators
				if (!this.$v.$invalid) {
					let order = await this.storeOrder(this.order);
					this.clearCart();
					this.$router.push(`/thanks/${order}`);
				}
			}
		}
	}
</script>