<template>
	<div class="row mt-2">
		<div class="col form-group">
<!--If you just specify the name of a method when using the v-on directive, the methods will receive an event object, which can be used to access details of the element that triggered the event.-->
			<select class="form-control" v-on:change="changePageSize">
				<option value="4">4 per page</option>
				<option value="8">8 per page</option>
				<option value="12">12 per page</option>
			</select>
		</div>
		<div class="text-right col">
			<div class="btn-group mx-2">
				<button v-for="i in pageNumbers" v-bind:key="i"
						class="btn btn-secpmdary"
						v-bind:class="{ 'btn-primary': i == currentPage }"
						v-on:click="setCurrentPage(i)">

				{{ i }}
				</button>
			</div>
		</div>
	</div>
</template>
<script>	
	import { mapState, mapGetters, mapMutations } from "vuex";
	export default {
		computed: {
			/*
This component uses the mapState and mapGetters helper functions to provide access to the data store currentPage and pageCount properties
			*/
			...mapState(["currentPage"]),
			...mapGetters(["pageCount"]),
			pageNumbers() {
				//keys()用于从数组中创建一个可迭代的对象，该对象包含数组的键(即位置下标0 1 2...)
				return [...Array(this.pageCount + 1).keys()].slice(1);
			}
		},
		methods: {
			/*The setCurrentPage is mapped to the data store mutation of the same name*/
			//...mapMutations(["setCurrentPage"]),
			...mapMutations(["setCurrentPage", "setPageSize"]),
			changePageSize($event) {
				this.setPageSize(Number($event.target.value));
			}
		}
	}
	
</script>