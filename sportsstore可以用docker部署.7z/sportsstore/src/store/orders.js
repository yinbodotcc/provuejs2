import Axios from "axios";
import Vue from "vue";
/*
The json-server package that I have used as the RESTful web service for the SportsStore application
responds to POST requests with a JSON representation of the object that includes an id property. The id
property is assigned automatically and is used to uniquely identify the stored object in the database
*/
//const ORDERS_URL = "http://localhost:3500/orders";
const ORDERS_URL = "/api/orders";

export default {
	state: {
		orders:[]
	},
	mutations: {
		setOrders(state, data) {
			state.orders = data;
		},
		//我理解为状态反转
		changeOrderShipped(state, order) {
			Vue.set(order, "shipped",
			order.shipped == null || !order.shipped ? true : false);
		}
	},
/* For variety, I have not enabled the namespace feature, which means that this module’s getters,
mutations, and actions will be merged with those in the index.js file and will not be accessed using a prefix*/

	actions: {
		async storeOrder(context, order) {
			/*
To get data from another module, I use the rootState property of the action’s context object, which lets
me navigate to the cart module’s lines property
			*/
			order.cartLines = context.rootState.cart.lines;
			//The storeOrder action uses the Axios package to send an HTTP POST request to the web service, which will store the order in the database
			return (await Axios.post(ORDERS_URL, order)).data.id;
		},
		async getOrders(context) {
			context.commit("setOrders",(await context.rootGetters.authenticatedAxios.get(ORDERS_URL)).data);
		},
		async updateOrder(context, order) {
			context.commit("changeOrderShipped", order);
			await context.rootGetters.authenticatedAxios.put(`${ORDERS_URL}/${order.id}`, order);
		}
	}
}