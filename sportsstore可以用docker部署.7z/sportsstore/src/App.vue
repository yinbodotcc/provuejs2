<template>
  <router-view />
</template>

<script>
  //import Store from "./components/Store";
  import { mapActions } from "vuex";
  export default {
    name: 'app',
    //components: { Store },

    methods: {
       //...mapActions(["getData"]),
       ...mapActions({
          getData: "getData",
          initializeCart: "cart/initializeCart"})       
    },
    //the data obtained from the RESTful web service
    created() {
       this.getData();
       this.initializeCart(this.$store);
    }
  }
</script>