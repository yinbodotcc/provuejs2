import Vue from 'vue'
import Vuelidate from "vuelidate";
import App from './App.vue'

Vue.config.productionTip = false

import "bootstrap/dist/css/bootstrap.min.css";
import "font-awesome/css/font-awesome.min.css";

import store from "./store";
import router from "./router";

//Creating a Global Filter.
//Global filters are defined using the Vue.filter method, which must be called before the Vue object is created
Vue.filter("currency", (value) => new Intl.NumberFormat("zh-CN",{ style: "currency", currency: "CNY" })
				.format(value));
/*Vue.filter("currency", (value) => new Intl.NumberFormat("en-US",
{ style: "currency", currency: "USD" }).format(value));*/

/*
Vuelidate is distributed as a Vue.js plugin that must be registered with the Vue.use method before 
the Vue object is created
*/
Vue.use(Vuelidate);

new Vue({
  render: h => h(App),
  //Adding the store property to the configuration property used to create the Vue object
  //ensures that the data store features can be used throughout the application
  store,
  router
}).$mount('#app')