<template>
  <store />
</template>

<script>
  import Store from "./components/Store";
  import { mapActions } from "vuex";
  export default {
    name: 'app',
    components: { Store },

    methods: {
		...mapActions(["getData"])
	},
	//the data obtained from the RESTful web service
	created() {
		this.getData();
	}
  }
</script>