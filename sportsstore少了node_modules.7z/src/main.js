import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

import "bootstrap/dist/css/bootstrap.min.css";
import "font-awesome/css/font-awesome.min.css";

import store from "./store";

new Vue({
  render: h => h(App),
  //Adding the store property to the configuration property used to create the Vue object
  //ensures that the data store features can be used throughout the application
  store
}).$mount('#app')