import Axios from "axios";
//const loginUrl = "http://localhost:3500/login";
const loginUrl = "/api/login";

export default {
	state: {
		authenticated: false,
		jwt: null
	},
	getters: {
		authenticatedAxios(state) {
			/*
The Axios create method is used to configure an object that can be used to make requests, and I use this feature in the authenticatedAxious
getter to provide an Axios object that will include the Authorization header in all the requests it makes
			*/
			return Axios.create({
				headers: {
					"Authorization": `Bearer<${state.jwt}>`
				}
			});
		}
	},
	mutations: {
		setAuthenticated(state, header) {
			state.jwt = header;
			state.authenticated = true;
		},
		clearAuthentication(state) {
			state.authenticated = false;
			state.jwt = null;
		}
	},
	actions: {
		async authenticate(context, credentials) {
			//给login.js发送一个post请求，验证credentials是否合法
			let response = await Axios.post(loginUrl, credentials);
			if (response.data.success == true) {
				context.commit("setAuthenticated", response.data.token);
			}
			/**
            问题： 如果第一次认证成功，然后重新到login，随便输入用户和口令，则authenticated根本不会被更新，即还是true
			*/
		}
	}
}