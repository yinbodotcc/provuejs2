//create a default export that returns an object with state, getters, and mutations properties
export default {
	//keep these features separate in the data store, which means they will be accessed with a prefix
	namespaced: true,
	state: {
		lines: []
	},
	getters: {
		itemCount: state => state.lines.reduce((total, line) =>total + line.quantity, 0),
		totalPrice: state => state.lines.reduce((total, line) =>total + (line.quantity * line.product.price), 0),
	},
	mutations: {
		addProduct(state, product) {
			let line = state.lines.find(line => line.product.id == product.id);
			if (line != null) {
				line.quantity++;
			} else {
				state.lines.push({ product: product, quantity:1 });
			}
		},
		changeQuantity(state, updateobj) {
			/*
			在ShoppingCart里面有这样的调用代码：this.change({ line, quantity: $event});
			实参是一个对象，line和quantity都是成员变量，所以下文才可以写成update.line.quantity = updateobj.quantity;

			*/
			updateobj.line.quantity = updateobj.quantity;
		},
		removeProduct(state, lineToRemove) {
			let index = state.lines.findIndex(line => line == lineToRemove);
			if (index > -1) {
				state.lines.splice(index, 1);
			}
		},
		//Actions are not allowed to modify state data directly in the data store, so I have also added a mutation that sets the lines property
		setCartData(state, data) {
			state.lines = data;
		}
	},
	//load, store, and clear the cart data using the local storage API
	actions: {
		loadCartData(context) {
			let data = localStorage.getItem("cart");
			if (data != null) {
				context.commit("setCartData", JSON.parse(data));
			}
		},
		storeCartData(context) {
			localStorage.setItem("cart", JSON.stringify(context.state.lines));
		},
		clearCartData(context) {
			context.commit("setCartData", []);
		},
		initializeCart(context, store) {
			context.dispatch("loadCartData");
			//a function that selects the state property and a function to invoke when a change is detected
			store.watch(state => state.cart.lines, () => context.dispatch("storeCartData"), { deep: true});
			//There is also a configuration object that sets the deep property to true, 
			//which tells Vuex that I want to receive notifications when there is a change 
			//to any of the properties in the lines array, which is not done by default.
			//without this option, I would receive notifications only when the user adds or removes a line 
			//from the cart and not when the quantity of an existing product selection is changed.
		}
	}
}