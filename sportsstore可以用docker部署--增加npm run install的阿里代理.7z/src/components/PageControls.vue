<template>
	<div class="row mt-2">
		<!--div class="col form-group"-->
		<div class="col-3 form-group">
<!--If you just specify the name of a method when using the v-on directive, the methods will receive an event object, which can be used to access details of the element that triggered the event.-->
			<select class="form-control" v-on:change="changePageSize">
				<option value="4">4 per page</option>
				<option value="8">8 per page</option>
				<option value="12">12 per page</option>
			</select>
		</div>
		<div class="text-right col">
			<button v-bind:disabled="currentPage == 1" v-on:click="setCurrentPage(currentPage - 1)"
					class="btn btn-secondary mx-1">Previous</button>
			<!--
			当前页至少到了5时，显示1...x x+1 x+2这个样子，这里只管展示1..（不到第五页按钮时，前面出现1234；）
			-->
			<span v-if="currentPage > 4">
				<button v-on:click="setCurrentPage(1)" class="btn btn-secondary mx-1">1</button>
				<span class="h4">...</span>
			</span>
			<span class="mx-1">
				<button v-for="i in pageNumbers" v-bind:key="i" class="btn btn-secpmdary"
					v-bind:class="{ 'btn-primary': i == currentPage }"
					v-on:click="setCurrentPage(i)">{{ i }}</button>
			</span>
			<span v-if="currentPage <= pageCount - 4">
				<span class="h4">...</span>
				<button v-on:click="setCurrentPage(pageCount)" class="btn btn-secondary mx-1">{{ pageCount}}</button>
			</span>

			<button v-bind:disabled="currentPage == pageCount" v-on:click="setCurrentPage(currentPage + 1)"
				class="btn btn-secondary mx-1">Next
			</button>
		</div>

	</div>
</template>
<script>	
	//import { mapState, mapGetters, mapMutations } from "vuex";
	import { mapState, mapGetters, mapActions } from "vuex";
	export default {
		computed: {
			/*
This component uses the mapState and mapGetters helper functions to provide access to the data store currentPage and pageCount properties
			*/
			...mapState(["currentPage"]),
			...mapGetters(["pageCount"]),
			pageNumbers() {
				//keys()用于从数组中创建一个可迭代的对象，该对象包含数组的键(即位置下标0 1 2...)
				//return [...Array(this.pageCount + 1).keys()].slice(1);

				//总共只有4行的，则全部显示
				if (this.pageCount <= 4) {
					return [...Array(this.pageCount + 1).keys()].slice(1);
					}
				//显示前5行 
				else if (this.currentPage <= 4) {
					return [1, 2, 3, 4, 5];
					} 
				//最后5行全部显示
				else if (this.currentPage > this.pageCount - 4) {
					return [...Array(5).keys()].reverse()
					.map(v => this.pageCount - v);
					} 
				//否则currentPage前后两行都显示
				else {
					return [this.currentPage -1, this.currentPage,
					this.currentPage + 1];
				}
			}
		},
		methods: {
			/*The setCurrentPage is mapped to the data store mutation of the same name*/
			//...mapMutations(["setCurrentPage"]),
			//...mapMutations(["setCurrentPage", "setPageSize"]),
			...mapActions(["setCurrentPage", "setPageSize"]),
			changePageSize($event) {
				this.setPageSize(Number($event.target.value));
			}			
		}
	}
	
</script>