import Vue from "vue";
import VueRouter from "vue-router";
import Store from "../components/Store";
import ShoppingCart from "../components/ShoppingCart";
import Checkout from "../components/Checkout";
import OrderThanks from "../components/OrderThanks";

/*
注意下面动态import语句写法
Normal import statements create a static dependency on a module, with the effect that importing a 
component ensures it is included in the JavaScript file that is sent to the browser. The type of import 
statement I used here is dynamic, which means that the components required for the administration features 
will be put into a separate JavaScript file that is loaded the first time any of these components are 
required. This ensures that the features are available for the small number of users who require them 
but are not downloaded by the rest of the users.
*/

const Authentication = () =>
import(/* webpackChunkName: "admin" */ "../components/admin/Authentication");
const Admin = () =>
import(/* webpackChunkName: "admin" */ "../components/admin/Admin");
const ProductAdmin = () =>
import(/* webpackChunkName: "admin" */ "../components/admin/ProductAdmin");
const OrderAdmin = () =>
import(/* webpackChunkName: "admin" */ "../components/admin/OrderAdmin");
const ProductEditor = () =>
import(/* webpackChunkName: "admin" */ "../components/admin/ProductEditor");
/*
上面import里面的注释是有用的，webpack工具可以读取这个元信息，具体解释如下：
The awkward comment that I have included in the import statement ensures that the components are packaged 
into a single separate file. Without these comments, each component would end up in a separate file that 
would be requested from the server the first time it is required. Since these components provide related 
features, I have grouped them together. This is a feature that is specific to the tool used by the Vue.js 
tools to produce bundles of JavaScript code—known as webpack-and it may not work unless you have
created your project using the Vue.js command-line tools
*/

import dataStore from "../store";

Vue.use(VueRouter);

export default new VueRouter({
	mode: "history",
	routes: [
		{ path: "/", component: Store },
		{ path: "/cart", component: ShoppingCart },
		{ path: "/checkout", component: Checkout},
		{ path: "/thanks/:id", component: OrderThanks},
		{ path: "/login", component: Authentication },
		{ path: "/admin", component: Admin,
			beforeEnter(to, from, next) {
				if (dataStore.state.auth.authenticated) {
				next();
				} else {
				next("/login");
				}
			},
			children: [
				{ path: "products/:op(create|edit)/:id(\\d+)?",
				component: ProductEditor },
				{ path: "products", component: ProductAdmin },
				{ path: "orders", component: OrderAdmin },
				{ path: "", redirect: "/admin/products"}
			]
		},
		{ path: "*", redirect: "/"}
	]
})