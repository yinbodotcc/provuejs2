<template>
	<div class="m-2 text-center">
		<h2>Thanks!</h2>
		<p>Thanks for placing your order, which is #{{orderId}}.</p>
		<p>We'll ship your goods as soon as possible.</p>
		<router-link to="/" class="btn btn-primary">Return to Store</router-link>
	</div>
</template>
<script>
	export default {
		computed: {
			orderId() {
				/*
				his.$route property, which is available in all components when the Vue Router package is enabled.  另外这个id来自orders.js返回值，我会增加一个新的路由：{ path: "/thanks/:id", component: OrderThanks},
				*/

				return this.$route.params.id;
			}
		}
	}
</script>